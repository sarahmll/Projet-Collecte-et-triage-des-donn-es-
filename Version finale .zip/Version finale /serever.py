from flask import Flask, render_template
from flask import Flask, request, flash, url_for, redirect, render_template
from flask_socketio import SocketIO, emit
from flask_socketio import join_room, leave_room
from flask_sqlalchemy import SQLAlchemy
from flask import request
import random
app = Flask(__name__)
app.config['SECRET_KEY'] = 'secret!'
socketio = SocketIO(app)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config ['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///velo.sqlite3'
db = SQLAlchemy(app)


###################### partie base de donées############################### 
class bikers(db.Model):

    login = db.Column('login', db.String(100), primary_key = True)
    def __init__(self,login):
        self.login=login

id_course = 5888
class courses(db.Model):
    nom_course=db.Column('nom_course',db.String(100),primary_key = True)
    def __init__(self, nom_course):
        self.nom_course = nom_course

class distances(db.Model):
    id_distance=db.Column('id_distance',db.Integer,primary_key=True)
    login =db.Column('login',db.String(100),db.ForeignKey('bikers.login'))
    nom_course =db.Column('nom_course',db.String(100),db.ForeignKey('courses.nom_course'))
    distance=db.Column('distance',db.Float(100))
    def __init__(self,id_distance,login,nom_course,distance):
        self.nom_course = nom_course
        self.login=login
        self.distance=distance



users={}
clients={}
room_users={}
liste_courses=[]
name_sid={}



i=0
def find_name_by_sid(sid):
    for i,j in name_sid.items():
        if(j==sid):
            return i
def find_room_by_name(name):
    for i , j in room_users.items():
        if(name in j ):
            return i

@socketio.on('message')
def test_message(message):
    #users[message["nom"]]={"long":message["lon"],"lat":message["lat"],"acc":message["acc"]}
    return

@socketio.on('my broadcast event')
def test_message(message):
    emit('my response', {'data': message['data']}, broadcast=True)
@socketio.on('login')
def test_message(message):
    nom=message['nom']
    sid=request.sid
    users[nom]=sid
    name_sid[nom]=sid
    biker=bikers(nom)
    db.session.add(biker)
    db.session.commit()
    #db.session.flush()
    emit('update_table',{'liste_courses':liste_courses},broadcast=True)


@socketio.on('connect')
def test_connect():
    global i
    clients[i]=request.sid
    i+=1
    print("c'est bon")
    emit('my response', {'data': 'Connected'})



@socketio.on('creer_course')
def test_message(message):
    if ((message['course']) not in liste_courses):
        liste_courses.append(message['course'])
    emit('update_table',{'liste_courses':liste_courses},broadcast=True)
    print(liste_courses)


@socketio.on('disconnect')
def test_disconnect():
    sid=request.sid
    name=find_name_by_sid(sid)
    room=find_room_by_name(name)
    if(room):
        if( name in room_users[room]):
            room_users[room].remove(name)
            print(name+ '  disconnected')
        emit("join_room",{"room":room,"users":room_users[room]}, to=room)
    print(room_users)



@socketio.on('commencer')
def commencer(data):
    room = data['room']
    course=data['course']
    liste_courses.remove(room)
    emit('update_table',{'liste_courses':liste_courses},broadcast=True)
    emit("commencer",{"room":room}, to=room)

@socketio.on('donnee')
def on_donnee(data):
    room = data['room']
    distance_parcourue=data['distance']
    login=data['nom']
    id_dist=random.randint(1,99999999)
    print(room)
    print(login)
    distance=distances(id_dist,login,room,distance_parcourue)
    db.session.add(distance)
    db.session.commit()


@socketio.on('finir')
def on_finir(data):
    room = data['room']
    del room_users[room]
    print("flefevfejfjfjfj**********************")
    emit("finir",{"room":room}, to=room)

@socketio.on('join')
def on_join(data):
    username = data['nom']
    room = data['room']
    join_room(room)
    if room in room_users.keys():
        room_users[room].append(username)
    else:

        course=courses(room)
        db.session.add(course)
        db.session.commit()
        room_users[room]=list()
        room_users[room].append(username)


    emit("join_room",{"room":room,"users":room_users[room]}, to=room)
    print("les users envoyé au "+ room)
    print(room_users[room])

@socketio.on('leave')
def on_leave(data):
    username = data['name']
    room = data['room']
    leave_room(room)
    print(username+" has left room")
    if(username in room_users[room]):
        room_users[room].remove(username)
        emit("join_room",{"room":room,"users":room_users[room]}, to=room)
    #send(username + ' has left the room.', to=room)
@app.route('/')
def show_all():
   return render_template('show_all.html', distances = distances.query.all(),bikers=bikers.query.all(),courses=courses.query.all())
if __name__ == '__main__':
    db.create_all()
    socketio.run(app, host='0.0.0.0')
