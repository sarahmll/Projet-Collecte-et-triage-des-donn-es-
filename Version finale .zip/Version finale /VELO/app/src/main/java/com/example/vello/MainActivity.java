package com.example.vello;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.view.View;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;


import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

import org.json.JSONException;
import org.json.JSONObject;
import org.json.*;

public class MainActivity extends AppCompatActivity {
    Button btnGetLogin;
    public static String nom;

    //initialisation de la socket

    public static Socket mSocket;

    // la liste des courses disponibles
    public static List<String> courses = new ArrayList<>();

    //la liste joueurs c'est la liste des joueurs dans la course
    public static List<String> joueurs = new ArrayList<>();

    //ici on fait la configuration pour la connexion n'oubliez pas a changer l'adresse
    //si vous voulez recuperer l'adresse de votre serveur tapez ifconfig est recupere l'adresse
    //qui correspond a en0 "http://votreadresse:5000"
    {
        try {
            mSocket = IO.socket("http://10.129.7.92:5000");
        } catch (URISyntaxException e) {
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //ici la connexion elle est faite
        mSocket.connect();

        // cet evenement sert a faire la mise à jour de la liste des courses disponibles
        // les données sont recuperer dans un  jsonobject ensuite on le met dans un jsonarray

        mSocket.on("update_table", new Emitter.Listener() {
            @Override
            public void call(Object... args) {
                JSONObject data = (JSONObject) args[0];
                JSONArray arr =null;
                try {
                    arr = data.getJSONArray("liste_courses");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                ;
                try {
                    courses = new ArrayList<>();
                    for(int i=0;i<arr.length();i++) {
                        courses.add(arr.getString(i)); // iterate the JSONArray and extract the keys
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        });

        // cet evenement sert a faire la mise à jour de la liste des joueurs de la course

        MainActivity.mSocket.on("join_room", new Emitter.Listener() {
            @Override
            public void call(Object... args) {
                JSONObject data = (JSONObject) args[0];
                JSONArray arr =null;
                try {
                    arr = data.getJSONArray("users");
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                ;
                try {
                    joueurs = new ArrayList<>();
                    for(int i=0;i<arr.length();i++) {
                        joueurs.add(arr.getString(i)); // iterate the JSONArray and extract the keys
                    }


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }

        });

        // cet evenement sert a informer les joueurs que la leader a commnecer la course
        // et quitter la salle d'attente vers la page de partie

        MainActivity.mSocket.on("commencer", new Emitter.Listener() {
            @Override
            public void call(Object... args) {
                Intent i = new Intent(getApplicationContext(), page_de_partie.class);
                startActivity(i);


            }

        });

        // cet evenement sert a informer les joueurs que le leader a fini la course et donc
        // chaque joueur vas envoyer ses informations au serveur pour les enregistrer dans la base
        // donnée par l'emit donnee
        MainActivity.mSocket.on("finir", new Emitter.Listener() {
            @Override
            public void call(Object... args) {
                JSONObject objnom = new JSONObject();
                try {
                    objnom.put("room", page_principale.room);
                    objnom.put("nom",MainActivity.nom);
                    objnom.put("distance", page_de_partie.distance_total);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                mSocket.emit("donnee",objnom);
                page_principale.room="";
                Intent i = new Intent(getApplicationContext(), page_principale.class);
                startActivity(i);


            }

        });
        // ce bouton sert a faire le login et aller à la page principale
        // pour rappel on ne peut pas avoir deux
        btnGetLogin = (Button) findViewById(R.id.getLogin);
        btnGetLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText text = (EditText)findViewById(R.id.nom);
                String value = text.getText().toString();

                MainActivity.nom=value;
                JSONObject objnom = new JSONObject();
                try {
                    objnom.put("nom",nom);
                } catch (JSONException e) {
                    e.printStackTrace();
                }


                mSocket.emit("login",objnom);
                Intent i = new Intent(getApplicationContext(), page_principale.class);
                startActivity(i);
            }
        });

    }



}