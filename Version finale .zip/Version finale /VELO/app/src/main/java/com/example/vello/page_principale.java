package com.example.vello;

import android.content.Intent;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import org.json.JSONException;
import org.json.JSONObject;

public class page_principale extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    Button btncreer;
    Button btnrejoindre;
    String selectedcourse;
    Spinner spinner;
    static String course;
    Handler handler = new Handler();
    Runnable runnable;
    int delay = 7000;

    public static String room;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_principale);
        btncreer = (Button) findViewById(R.id.creer);
        btnrejoindre = (Button) findViewById(R.id.rejoindre);
        spinner=(Spinner)findViewById(R.id.spinner);
        spinner.setVisibility(View.GONE);
        btnrejoindre.setVisibility(View.GONE);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_activated_1,MainActivity.courses);
        spinner.setAdapter(adapter);

        /*
            en cliquant sur ce bouton deux emit sont envoyer au serveur 'join' et 'creer_course'
            pour rentrer dans la room et la deuxieme pour creer un la structure de la course
         */

        btncreer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String course="course_"+MainActivity.nom;
                page_principale.course=course;
                room=course;
                JSONObject objcourse = new JSONObject();
                try {
                    objcourse.put("course", course);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                JSONObject obj = new JSONObject();
                try {
                    obj.put("room", room);
                    obj.put("nom", MainActivity.nom);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                MainActivity.mSocket.emit("join", obj);
                MainActivity.mSocket.emit("creer_course",objcourse);
                Intent i = new Intent(getApplicationContext(),salleAttente.class);
                startActivity(i);
            }
        });

        /*
            en cliquant sur le bouton rejoindre un emit 'join' envoyer au serveur avec le nom de la
            course qui souhaite rejoindre
         */
        btnrejoindre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = spinner.getSelectedItem().toString();
                Log.d("cc",text);
                room=text;
                page_principale.course=text;
                JSONObject obj = new JSONObject();
                try {
                    obj.put("room", room);
                    obj.put("nom", MainActivity.nom);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                MainActivity.mSocket.emit("join", obj);
                Intent i = new Intent(getApplicationContext(),salleAttente.class);
                startActivity(i);
            }
        });

    }

    @Override
    protected void onResume() {
        handler.postDelayed(runnable = new Runnable() {
            public void run() {
                handler.postDelayed(runnable, delay);
                ArrayAdapter<String> adapter=new ArrayAdapter<String>(page_principale.this, android.R.layout.simple_list_item_activated_1,MainActivity.courses);
                spinner.setAdapter(adapter);
                if(adapter.getCount()>0){
                   spinner.setVisibility(View.VISIBLE);
                   btnrejoindre.setVisibility(View.VISIBLE);
                }
                else {
                    spinner.setVisibility(View.GONE);
                    btnrejoindre.setVisibility(View.GONE);
                }
            }
        }, delay);
        super.onResume();
    }
    /*
        cette fonction a pour but de recuperer l'item selectionner
     */
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text=parent.getItemAtPosition(position).toString();
        selectedcourse =text;
        Log.d("tg",text);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}