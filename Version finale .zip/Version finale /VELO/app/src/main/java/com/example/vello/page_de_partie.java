package com.example.vello;

import android.Manifest;
import android.content.Intent;
import android.location.Location;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class page_de_partie extends AppCompatActivity {

    TextView mTextViewlogin;
    TextView mTextViewlong;
    TextView mTextViewid;
    TextView mTextViewlat;
    TextView mTextViewdist;
    TextView mTextViewacc;
    double departlon;
    double lon_initiale;
    double lat_initiale;
    double departlat;
    double globallat ;
    double globallon;
    static double distance_total=0.0;
    long delay=4000;
    long temps=0;
    Handler handler = new Handler();
    Runnable runnable;
    Button btnFinir;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_de_partie);

        mTextViewlogin = (TextView) findViewById(R.id.showlogin);
        mTextViewdist = (TextView) findViewById(R.id.showdist);
        mTextViewid = (TextView) findViewById(R.id.showid);
        mTextViewlong = (TextView) findViewById(R.id.showlong);
        mTextViewlat = (TextView) findViewById(R.id.showlat);
        mTextViewlogin.setText(MainActivity.nom);
        mTextViewacc = (TextView) findViewById(R.id.acc);

        mTextViewid.setText(page_principale.room);



        btnFinir = (Button) findViewById(R.id.finjeu);
        btnFinir.setVisibility(View.GONE);
        ActivityCompat.requestPermissions(page_de_partie.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 123);
        sendinf();



        departlon=globallon;
        departlat=globallat;
        lon_initiale=globallon;
        lat_initiale=globallat;

        Log.d("tlon", String.valueOf(departlon));
        Log.d("tlat", String.valueOf(departlat));


        btnFinir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                JSONObject objnom = new JSONObject();
                try {
                    objnom.put("room", page_principale.room);
                    objnom.put("nom",MainActivity.nom);
                    objnom.put("distance",distance_total);
                } catch (JSONException e) {
                    e.printStackTrace();
                }


                MainActivity.mSocket.emit("finir",objnom);
            }
        });

    }
    //ce bout de code a pour but de sortir de la corse si on click sur le bouton pour revenir
    @Override
    public void onBackPressed() {
        JSONObject objnom = new JSONObject();
        try {
            objnom.put("room", page_principale.room);
            objnom.put("name",MainActivity.nom);

        } catch (JSONException e) {
            e.printStackTrace();
        }
        MainActivity.mSocket.emit("leave",objnom);
        Intent i = new Intent(getApplicationContext(), page_principale.class);
        startActivity(i);
        handler.removeMessages(0);
        finish();

    }
    // ce handler pour renitialiser chaque delay=4s
    @Override
    protected void onResume() {
        handler.postDelayed(runnable = new Runnable() {
            public void run() {
                handler.postDelayed(runnable, delay);
                sendinf();
                temps+=4;
                electiondurantlejeu();
                calculdistance(departlon,globallon,departlat,globallat);
                departlon=globallon;
                departlat=globallat;

            }
        }, delay);
        super.onResume();
    }

    private void electiondurantlejeu() {
        List<String> joueurs = new ArrayList<>();
        joueurs = MainActivity.joueurs;
        String max;
        max= Collections.max(joueurs,null);
        salleAttente.leader=max;

        if(salleAttente.leader.equals(MainActivity.nom)){
            btnFinir.setVisibility(View.VISIBLE);
        }
        else {
            btnFinir.setVisibility(View.GONE);
        }
    }

    /*cette fonction a pour but de calculer la distance entre deux positions est l'incrementer au
     variable distances_total
     params{lon1=longtitude de la position intiale , lon2 =longtitude de la nouvelle position
     lat1=latitude de la position intiale , lat2 =latitude de la nouvelle position ,
    */
    public void  calculdistance(double lon1,double lon2,double lat1,double lat2){
        final int R = 6371; // Radius of the earth

        double latDistance = Math.toRadians(lat2 - lat1);
        double lonDistance = Math.toRadians(lon2 - lon1);
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double distance = R * c ; // convert to meters

        distance_total+=distance;
        double d = (double) Math.round(distance_total * 100) / 100;
        distance_total=d;
        mTextViewdist.setText(" " + d+ " km ");

    }

    /*
        cette fonction sert a recuper la postion et la vitesse actuelle et afficher le resultats
        dans la page page_de_partie
    */
    public void sendinf() {
        GPStracker g = new GPStracker(getApplicationContext());
        Location l = g.getLocation();
        if (l != null) {
            JSONObject obj = new JSONObject();
            double lat =l.getLatitude() ;
            double lon =l.getLongitude();
            double acc=l.getSpeed();
            acc=acc*3.6;
            acc = (double) Math.round(acc * 100) / 100;



            try {
                obj.put("lat", lat);
                obj.put("lon", lon);
                obj.put("acc", acc);
                obj.put("nom", MainActivity.nom);
            } catch (JSONException e) {
                e.printStackTrace();
            }
            globallat=lat;
            globallon=lon;
            mTextViewlat.setText(" " + lat);
            mTextViewlong.setText(" " + lon);
            mTextViewacc.setText(" " + acc + " km/heure");
            MainActivity.mSocket.emit("message", obj);
        }
    }
}