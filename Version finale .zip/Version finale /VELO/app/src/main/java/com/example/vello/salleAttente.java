package com.example.vello;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.os.Handler;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/*
    cette page c'est  la salle d'attente ou tous les joueurs attendrons a ce que le leader commence
    la course
*/

public class salleAttente extends AppCompatActivity {
    ListView l;
    Handler handler = new Handler();
    Runnable runnable;
    public static String leader;
    Button btnCommencer;


    int delay = 1000;
    public static ArrayAdapter<String> arrnames;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_salle_attente);
        btnCommencer = (Button) findViewById(R.id.commencer);
        btnCommencer.setVisibility(View.GONE);
        l = findViewById(R.id.list);

        arrnames
                = new ArrayAdapter<String>(
                this,
                R.layout.support_simple_spinner_dropdown_item,
                MainActivity.joueurs);
        l.setAdapter(arrnames);
        btnCommencer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                JSONObject objnom = new JSONObject();
                try {
                    objnom.put("room", page_principale.room);
                    objnom.put("course", page_principale.course);
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                MainActivity.mSocket.emit("commencer",objnom);
                Intent i = new Intent(getApplicationContext(), page_de_partie.class);
                startActivity(i);
            }
        });

    }

    @Override
    protected void onResume() {
        handler.postDelayed(runnable = new Runnable() {
            public void run() {
                handler.postDelayed(runnable, delay);
                arrnames
                        = new ArrayAdapter<String>(
                        salleAttente.this,
                        R.layout.support_simple_spinner_dropdown_item,
                        MainActivity.joueurs);
                l.setAdapter(arrnames);
                election();

            }
        }, delay);
        super.onResume();
    }

    /*
        pour l'election on recupere la liste et on compare les differents élements
        celui qui a le poids le plus grand sera le leader et aura accer au bouton commencer
     */
    public  void election() {
        List<String> joueurs = new ArrayList<>();
        joueurs = MainActivity.joueurs;
        String max;
        max= Collections.max(joueurs,null);
        TextView myAwesomeTextView = (TextView)findViewById(R.id.leadertext);
        myAwesomeTextView.setText(max);
        leader=max;

        if(leader.equals(MainActivity.nom)){
            btnCommencer.setVisibility(View.VISIBLE);
        }
        else {
            btnCommencer.setVisibility(View.GONE);
        }
    }
}